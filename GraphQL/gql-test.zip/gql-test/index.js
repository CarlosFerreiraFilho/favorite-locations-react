import { ApolloServer } from "apollo-server-express";
import express from "express";
import https from "https";
import fs from "fs";
import typeDefs from "./src/schema.js";
import locations from "./src/database.js"
import Query from "./src/resolvers/query.js"
import Mutation from "./src/resolvers/mutation.js";

// Resolvers
const resolvers = { Query, Mutation };
const context = { locations }

// Criar instância do Apollo Server
const server = new ApolloServer({ typeDefs, resolvers, context });
await server.start();

// Criar aplicação Express
const app = express();
server.applyMiddleware({ app });

// Configurações HTTPS
const PORT = 4000;
const HOST = "192.168.0.186";
const options = {
    key: fs.readFileSync("server.key"),
    cert: fs.readFileSync("server.cert"),
};

// Criar servidor HTTPS
const httpsServer = https.createServer(options, app);

httpsServer.listen(PORT, HOST, () => {
    console.log(`🚀 Servidor em execução com HTTPS: https://${HOST}:${PORT}${server.graphqlPath}`);
});
