import { v4 } from "uuid";

const Mutation = {
    addLocation: (_, args, context) => {
        const { newLocation } = args;
        const { locations } = context;

        newLocation.id = v4();
        newLocation.created_at = new Date();
        locations.push(newLocation);

        return newLocation;
    },

    updateLocation: (_, args, context) => {
        const { location } = args;
        const { locations } = context;

        for (let i = 0; i < locations.length; i++) {
            const location_ = locations[i];
            if (location_.id == location.id) {
                locations[i] = { ...location_, ...location }
                locations[i].updated_at = new Date().toLocaleString()
                return locations[i];
            }
        }

        return null;
    }
}

export default Mutation;