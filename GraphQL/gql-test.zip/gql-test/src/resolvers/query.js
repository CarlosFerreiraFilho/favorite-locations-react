const Query = {
    welcome: () => "Olá",
    locations: (_, args, context) => {
        const user_uid = args.user_uid;
        const { locations } = context
        console.log(user_uid)
        return locations.filter(location => location.user_uid === user_uid);
    }
}

export default Query;