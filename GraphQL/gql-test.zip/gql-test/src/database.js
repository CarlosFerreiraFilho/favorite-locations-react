
// Dados de exemplo
const locations = [
    {
        id: "1",
        name: "Local A",
        latitude: "-23.550520",
        longitude: "-46.633308",
        markerColor: "#FF0000",
        user_uid: "T4tvUaJ8RFeqSdmfYOKSNW8lgzE2",
        created_at: "2024-01-01T10:00:00Z",
        updated_at: "2024-01-02T12:00:00Z"
    },
    {
        id: "2",
        name: "Local B",
        latitude: "-22.970722",
        longitude: "-43.182365",
        markerColor: "#00FF00",
        user_uid: "user_345",
        created_at: "2024-02-01T08:00:00Z",
        updated_at: "2024-02-02T14:00:00Z"
    },
    {
        id: "3",
        name: "Local C",
        latitude: "-15.779720",
        longitude: "-47.929723",
        markerColor: "#0000FF",
        user_uid: "T4tvUaJ8RFeqSdmfYOKSNW8lgzE2",
        created_at: "2024-03-01T09:30:00Z",
        updated_at: "2024-03-02T11:45:00Z"
    }
];

export default locations;