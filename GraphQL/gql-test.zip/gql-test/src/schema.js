import { gql } from "apollo-server-express";

// Definições do esquema GraphQL
const typeDefs = gql`
    type Query {
        welcome: String
        locations(user_uid: String!): [LocationBodyModel]
    }

    type LocationBodyModel {
        id: String
        name: String
        latitude: String
        longitude: String
        markerColor: String
        user_uid: String
        created_at: String
        updated_at: String
    }          

    type Mutation {
        addLocation(newLocation: addLocationInput): LocationBodyModel!
        updateLocation(location: updateLocationInput): LocationBodyModel!
    }

    input addLocationInput {
        name: String
        latitude: String
        longitude: String
        markerColor: String
        user_uid: String
        created_at: String
        updated_at: String
    }

    input updateLocationInput {
        id: String
        name: String
        latitude: String
        longitude: String
        markerColor: String
        updated_at: String
    }
`;

export default typeDefs;